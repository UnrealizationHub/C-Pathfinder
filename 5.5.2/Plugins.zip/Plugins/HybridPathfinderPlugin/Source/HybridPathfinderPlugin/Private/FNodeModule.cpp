// Fill out your copyright notice in the Description page of Project Settings.


#include "FNodeModule.h"

FNodeModule::FNodeModule()
{
}

FNodeModule::~FNodeModule()
{
}

float FNodeModule::F() const
{
	return G + H;
}

bool FNodeModule::equals(const FNodeModule& Other)
{
	return Position == Other.Position;
}

bool FNodeModule::operator<(const FNodeModule& Other)
{
	return F() < Other.F();
}

bool FNodeModule::operator>(const FNodeModule& Other)
{
	return F() > Other.F();
}

bool FNodeModule::operator<=(const FNodeModule& Other)
{
	return F() <= Other.F();
}

bool FNodeModule::operator>=(const FNodeModule& Other)
{
	return F() >= Other.F();
}
